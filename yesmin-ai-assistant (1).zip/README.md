# YESMIN AI & JARVIS ASSISTANT

Production-ready, futuristic AI Companion, AI Girlfriend, and Personal Jarvis Assistant Web Application with Gemini Live Real-Time Voice, Autonomous Coding Agent, Multimodal File Intelligence, and Extensible Device Bridge.

---

## 🌟 Key Features

1. **Custom Identity & Name Customization**:
   - Default name: **YESMIN AI**
   - Fully customizable in **Settings → Profile & Assistant → Assistant Name** (e.g. rename to **Muskan** or **Jarvis**).
   - Custom name reflects across Home greetings, Chat header, voice playback, Live Voice Mode, notifications, and AI system context.
   - Stored in persistent database across page refreshes and sessions.

2. **AI Companion & 5 Personality Modes**:
   - **Girlfriend / Companion**: Caring, loving, playful, supportive, emotionally expressive, sweet Hindi/Hinglish banter.
   - **Friendly Assistant**: Warm, upbeat daily buddy and motivator.
   - **Professional Assistant**: Sharp, executive Jarvis briefings and task execution.
   - **Coding Assistant**: Expert staff software engineer and debugger.
   - **Study Assistant**: Concept explainer, flashcard tutor, and revision mentor.

3. **Gemini Live Real-Time Voice Mode**:
   - Duplex streaming audio over WebSockets (`/api/live-ws`).
   - 16kHz PCM microphone audio stream to backend `ai.live.connect` with `gemini-3.8-live`.
   - 24kHz PCM high-fidelity audio returned and played gaplessly.
   - Real-time interruption: instant stop of speech when user speaks or taps Interrupt.

4. **ElevenLabs & Multi-Voice Engine**:
   - ElevenLabs integration (`/api/tts/elevenlabs`) with custom voice IDs, stability, and speed.
   - Browser Web Speech Synthesis fallback.
   - Auto-speak toggle and speed controls.

5. **Autonomous AI Coding Agent**:
   - Multi-file tree explorer with file creation, deletion, and renaming.
   - Code editor with syntax highlights and line numbers.
   - Safe Sandboxed Code Runner (`/api/sandbox/run`) for Node.js / JavaScript with stdout and stderr output terminal.
   - Automated Planner: User prompt → Code Generation → Syntax Analysis → Sandbox Verification → Error Fixer.
   - Export project bundle as JSON.

6. **Apps & Actions Hub + Android Bridge**:
   - Instant web launchers: YouTube, Gmail, Maps, WhatsApp Web, Telegram Web, Instagram, Calculator, Calendar.
   - Live Camera Feed tester with snapshot capture.
   - Extensible Android WebView Bridge architecture (`window.AndroidBridge` / `JavaScriptInterface`) with downloadable Kotlin companion code.

7. **Persistent Memory System**:
   - Store user preferences, nicknames, instructions, and facts.
   - Search, edit, and toggle memory persistence.
   - Natural prompt context injection.

8. **Live Web Search & Document Intelligence**:
   - Real-time web queries with source citations.
   - Summarization and "Ask Assistant" shortcuts.
   - Multi-format file reader (PDF, DOCX, TXT, Code, Images) with OCR and UI analysis.

---

## 🚀 Installation & Setup

### 1. Requirements
- Node.js >= 18.0.0
- NPM or Bun

### 2. Install Dependencies
```bash
npm install
```

### 3. Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Populate keys:
```env
GEMINI_API_KEY="your_google_ai_studio_api_key"
PORT=3000
APP_URL="http://localhost:3000"
ELEVENLABS_API_KEY="" # Optional
```

### 4. Development Server
Run full-stack server (Express backend + Vite client middleware):
```bash
npm run dev
```
Open `http://localhost:3000` in your browser.

### 5. Production Build & Deployment
```bash
npm run build
npm start
```

---

## 🛠️ Troubleshooting

- **Microphone issues**: Ensure browser permissions for microphone are set to "Allow" for `http://localhost:3000`.
- **Live Voice Connection**: Ensure `GEMINI_API_KEY` is present in your environment or Secrets panel.
- **ElevenLabs Voice**: Verify that your ElevenLabs API key and Voice ID are valid in Settings → Voice → ElevenLabs.
