import React from 'react';
import { useApp, TabType } from '../context/AppContext';
import {
  Home,
  MessageSquare,
  Radio,
  Terminal,
  Zap,
  Search,
  FileText,
  Brain,
  FolderGit2,
  CheckSquare,
  Settings,
  Sparkles,
} from 'lucide-react';
import { getEffectiveAssistantName } from '../utils/personality';

export const Navigation: React.FC = () => {
  const { activeTab, setActiveTab, settings } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const mainNavItems: { id: TabType; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" /> },
    { id: 'chat', label: 'AI Chat', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'live', label: 'Live Voice', icon: <Radio className="w-5 h-5" />, badge: 'LIVE' },
    { id: 'code', label: 'Coding Agent', icon: <Terminal className="w-5 h-5" /> },
    { id: 'actions', label: 'Apps & Actions', icon: <Zap className="w-5 h-5" /> },
    { id: 'search', label: 'Web Search', icon: <Search className="w-5 h-5" /> },
    { id: 'files', label: 'Files & Docs', icon: <FileText className="w-5 h-5" /> },
    { id: 'memory', label: 'Memory', icon: <Brain className="w-5 h-5" /> },
    { id: 'projects', label: 'Projects', icon: <FolderGit2 className="w-5 h-5" /> },
    { id: 'tasks', label: 'Tasks & Alerts', icon: <CheckSquare className="w-5 h-5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> },
  ];

  // Mobile bottom navigation items (Exact specification: Home | Chat | Live | Code | Settings)
  const mobileNavItems: { id: TabType; label: string; icon: React.ReactNode; isSpecial?: boolean }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" /> },
    { id: 'chat', label: 'Chat', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'live', label: 'Live', icon: <Radio className="w-5 h-5" />, isSpecial: true },
    { id: 'code', label: 'Code', icon: <Terminal className="w-5 h-5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <>
      {/* Desktop Sidebar (hidden on small mobile screens) */}
      <aside className="hidden md:flex flex-col w-64 shrink-0 border-r border-purple-900/30 bg-slate-950/80 backdrop-blur-2xl p-4 justify-between h-full select-none">
        <div className="space-y-6">
          {/* Logo / Brand Banner */}
          <div className="flex items-center gap-3 px-3 py-2 rounded-2xl bg-gradient-to-r from-purple-950/60 to-slate-900/60 border border-purple-800/40 shadow-inner">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-600 flex items-center justify-center shadow-[0_0_15px_rgba(236,72,153,0.4)]">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="overflow-hidden">
              <h2 className="text-sm font-bold text-white truncate tracking-wide">
                {assistantName}
              </h2>
              <p className="text-[11px] text-pink-400 font-medium tracking-wider uppercase">
                Jarvis AI Hub
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {mainNavItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-transparent text-white border-l-4 border-pink-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={isActive ? 'text-pink-400' : 'text-slate-400'}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-pink-500/30 text-pink-300 border border-pink-500/40 animate-pulse">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Assistant Status Card */}
        <div className="p-3 rounded-2xl border border-purple-900/40 bg-purple-950/20 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Model Core</span>
            <span className="text-pink-400 font-semibold">{settings.geminiModel || 'gemini-3.8-flash'}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Live Voice Engine</span>
            <span className="text-emerald-400">Ready</span>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation (Visible on mobile screens) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-2xl border-t border-purple-900/40 px-2 py-1.5 flex items-center justify-around shadow-2xl safe-area-pb">
        {mobileNavItems.map((item) => {
          const isActive = activeTab === item.id;

          if (item.isSpecial) {
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className="relative -top-3 flex flex-col items-center group"
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-transform ${
                    isActive
                      ? 'bg-gradient-to-tr from-pink-500 to-purple-600 shadow-[0_0_20px_rgba(236,72,153,0.8)] scale-110'
                      : 'bg-gradient-to-tr from-pink-600 to-purple-700 shadow-pink-500/30'
                  }`}
                >
                  <Radio className="w-6 h-6 text-white animate-pulse" />
                </div>
                <span className="text-[10px] font-semibold text-pink-300 mt-1">Live</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
                isActive ? 'text-pink-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className={`p-1 rounded-lg ${isActive ? 'bg-pink-500/10' : ''}`}>
                {item.icon}
              </span>
              <span className="text-[11px]">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
