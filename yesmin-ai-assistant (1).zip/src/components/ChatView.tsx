import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { ChatMessage, Conversation } from '../types';
import { getEffectiveAssistantName, getEffectiveNickname, buildSystemPrompt } from '../utils/personality';
import { parseAssistantActions } from '../utils/tools';
import { DeviceBridge } from '../utils/androidBridge';
import {
  Send,
  Mic,
  MicOff,
  Square,
  RefreshCw,
  Copy,
  Check,
  Edit2,
  Trash2,
  Plus,
  Search,
  Volume2,
  VolumeX,
  Paperclip,
  Image as ImageIcon,
  ExternalLink,
  Zap,
  Sparkles,
  Bot,
  User,
} from 'lucide-react';

export const ChatView: React.FC = () => {
  const {
    settings,
    currentConversationId,
    setCurrentConversationId,
    showToast,
    setAssistantStatus,
  } = useApp();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSpeakingAudio, setIsSpeakingAudio] = useState(false);
  const [selectedImages, setSelectedImages] = useState<{ base64: string; mimeType: string; name: string }[]>([]);

  const assistantName = getEffectiveAssistantName(settings.assistantName);
  const nickname = getEffectiveNickname(settings.userNickname);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const currentAudioElementRef = useRef<HTMLAudioElement | null>(null);

  // Load conversations on mount
  useEffect(() => {
    loadConversations();
  }, []);

  // Check if a prompt was forwarded from home dashboard
  useEffect(() => {
    const pending = sessionStorage.getItem('pending_quick_prompt');
    if (pending) {
      sessionStorage.removeItem('pending_quick_prompt');
      setInputText(pending);
    }
  }, []);

  // Load messages when conversation changes
  useEffect(() => {
    if (currentConversationId) {
      loadMessages(currentConversationId);
    }
  }, [currentConversationId]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGenerating]);

  const loadConversations = async () => {
    try {
      const list = await api.getConversations();
      setConversations(list);
      if (list.length > 0 && !currentConversationId) {
        setCurrentConversationId(list[0].id);
      }
    } catch (err: any) {
      showToast(err.message || 'Error loading chats', 'error');
    }
  };

  const loadMessages = async (convId: string) => {
    try {
      const msgs = await api.getMessages(convId);
      setMessages(msgs);
    } catch (err: any) {
      showToast(err.message || 'Error loading messages', 'error');
    }
  };

  const handleNewConversation = async () => {
    try {
      const newConv = await api.createConversation(`Chat with ${assistantName}`);
      setConversations((prev) => [newConv, ...prev]);
      setCurrentConversationId(newConv.id);
      setMessages([]);
      showToast('New conversation created', 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to create chat', 'error');
    }
  };

  const handleDeleteConversation = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await api.deleteConversation(id);
      const remaining = conversations.filter((c) => c.id !== id);
      setConversations(remaining);
      if (currentConversationId === id) {
        if (remaining.length > 0) {
          setCurrentConversationId(remaining[0].id);
        } else {
          handleNewConversation();
        }
      }
      showToast('Conversation deleted', 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete chat', 'error');
    }
  };

  // TTS Playback (ElevenLabs or Browser Web Speech)
  const speakText = async (text: string) => {
    stopSpeaking();
    setIsSpeakingAudio(true);
    setAssistantStatus('speaking');

    try {
      if (settings.voiceProvider === 'elevenlabs') {
        const audioBlob = await api.synthesizeElevenLabs(text);
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        currentAudioElementRef.current = audio;
        audio.playbackRate = settings.voiceSpeed || 1;
        audio.onended = () => {
          setIsSpeakingAudio(false);
          setAssistantStatus('idle');
        };
        audio.onerror = () => {
          setIsSpeakingAudio(false);
          setAssistantStatus('idle');
          browserSpeak(text); // Fallback
        };
        audio.play();
      } else {
        browserSpeak(text);
      }
    } catch (err) {
      console.warn('Voice playback fallback:', err);
      browserSpeak(text);
    }
  };

  const browserSpeak = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setIsSpeakingAudio(false);
      setAssistantStatus('idle');
      return;
    }
    window.speechSynthesis.cancel();
    const clean = text.replace(/[*#`_\[\]()]/g, '');
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = settings.voiceSpeed || 1;
    utterance.volume = settings.volume || 1;

    // Pick Hindi or English voice if available
    const voices = window.speechSynthesis.getVoices();
    const hiVoice = voices.find((v) => v.lang.startsWith('hi'));
    if (settings.language === 'hindi' && hiVoice) {
      utterance.voice = hiVoice;
    }

    utterance.onend = () => {
      setIsSpeakingAudio(false);
      setAssistantStatus('idle');
    };
    utterance.onerror = () => {
      setIsSpeakingAudio(false);
      setAssistantStatus('idle');
    };
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (currentAudioElementRef.current) {
      currentAudioElementRef.current.pause();
      currentAudioElementRef.current = null;
    }
    setIsSpeakingAudio(false);
    setAssistantStatus('idle');
  };

  // Speech-To-Text Microphone
  const toggleRecording = () => {
    if (isRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
      setAssistantStatus('idle');
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      showToast('Speech recognition not supported in this browser', 'warning');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang =
        settings.language === 'hindi'
          ? 'hi-IN'
          : settings.language === 'hinglish'
          ? 'en-IN'
          : 'en-US';

      recognition.onstart = () => {
        setIsRecording(true);
        setAssistantStatus('listening');
      };

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        setInputText(transcript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsRecording(false);
        setAssistantStatus('idle');
        if (event.error !== 'no-speech') {
          showToast(`Microphone: ${event.error}`, 'warning');
        }
      };

      recognition.onend = () => {
        setIsRecording(false);
        setAssistantStatus('idle');
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      showToast('Microphone permission required', 'warning');
      setIsRecording(false);
    }
  };

  // Send message
  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || inputText;
    if (!textToSend.trim() && selectedImages.length === 0) return;

    if (isGenerating) return;

    const convId = currentConversationId || (await handleNewConversationAndGetId());

    const userAttachments = selectedImages.map((img) => ({
      name: img.name,
      type: img.mimeType,
      dataUrl: img.base64,
    }));

    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      conversationId: convId,
      role: 'user',
      content: textToSend,
      attachments: userAttachments,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setSelectedImages([]);
    setIsGenerating(true);
    setAssistantStatus('thinking');

    try {
      // Save user message in DB
      await api.saveMessage(convId, userMsg);

      // Load memories to include in system prompt
      const memories = await api.getMemories().catch(() => []);
      const systemInstruction = buildSystemPrompt(settings, memories);

      const historyPayload = messages.slice(-8).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      // Call Chat backend
      const responseText = await api.generateChat({
        conversationId: convId,
        prompt: textToSend,
        history: historyPayload,
        systemInstruction,
        images: userAttachments.map((att) => ({
          base64: att.dataUrl || '',
          mimeType: att.type,
        })),
      });

      // Parse actions if assistant produced action tags
      const { cleanText, actions } = parseAssistantActions(responseText);

      const assistantMsg: ChatMessage = {
        id: `msg_a_${Date.now()}`,
        conversationId: convId,
        role: 'assistant',
        content: cleanText,
        actions,
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setAssistantStatus('idle');

      // If auto-speak is enabled, speak the answer
      if (settings.autoSpeak) {
        speakText(cleanText);
      }
    } catch (err: any) {
      showToast(err.message || 'Generation error', 'error');
      setAssistantStatus('idle');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleNewConversationAndGetId = async (): Promise<string> => {
    const conv = await api.createConversation(`Chat with ${assistantName}`);
    setConversations((prev) => [conv, ...prev]);
    setCurrentConversationId(conv.id);
    return conv.id;
  };

  const handleRegenerate = async (lastUserMessageIndex: number) => {
    const lastUserMsg = messages[lastUserMessageIndex];
    if (!lastUserMsg) return;
    // Remove subsequent messages
    setMessages((prev) => prev.slice(0, lastUserMessageIndex + 1));
    await handleSendMessage(lastUserMsg.content);
  };

  const handleDeleteMessage = async (id: string) => {
    try {
      await api.deleteMessage(id);
      setMessages((prev) => prev.filter((m) => m.id !== id));
      showToast('Message deleted', 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete message', 'error');
    }
  };

  const handleSaveEdit = async (msgId: string) => {
    if (!editingContent.trim()) return;
    setMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, content: editingContent } : m))
    );
    setEditingMessageId(null);
    showToast('Message updated', 'success');
  };

  const handleCopy = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    showToast('Copied to clipboard', 'info');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImages((prev) => [
          ...prev,
          {
            name: file.name,
            mimeType: file.type || 'image/png',
            base64: reader.result as string,
          },
        ]);
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const executeActionCard = (action: any) => {
    if (action.type === 'OPEN_URL' || action.type === 'OPEN_APP') {
      DeviceBridge.executeAction(action.type, action.parameters);
      showToast(`Action dispatched: ${action.title}`, 'success');
    }
  };

  // Filter conversations
  const filteredConversations = conversations.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex h-full overflow-hidden">
      {/* Left Chat History Drawer (collapsible / responsive) */}
      <div className="hidden lg:flex flex-col w-72 shrink-0 border-r border-purple-900/30 bg-slate-950/70 backdrop-blur-xl p-3.5 space-y-3">
        <button
          onClick={handleNewConversation}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-semibold text-xs shadow-lg shadow-pink-500/20 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Conversation</span>
        </button>

        {/* Search Chats */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900/80 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-pink-500/50"
          />
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto space-y-1 pr-1">
          {filteredConversations.map((conv) => {
            const isActive = conv.id === currentConversationId;
            return (
              <div
                key={conv.id}
                onClick={() => setCurrentConversationId(conv.id)}
                className={`group flex items-center justify-between p-2.5 rounded-xl cursor-pointer text-xs transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-pink-500/20 to-purple-500/10 text-white border-l-2 border-pink-500 font-medium'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <span className="truncate flex-1 pr-2">{conv.title}</span>
                <button
                  onClick={(e) => handleDeleteConversation(conv.id, e)}
                  title="Delete chat"
                  className="opacity-0 group-hover:opacity-100 hover:text-red-400 p-1 rounded transition-opacity"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Chat Stream Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950/40 relative">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 pb-32">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4 max-w-md mx-auto my-auto">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-[0_0_30px_rgba(236,72,153,0.4)]">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-bold text-white">
                Chat with {assistantName}
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                Ask anything, code together, share documents, or chat in Hindi, Hinglish, and English.
              </p>
              <div className="flex flex-wrap gap-2 justify-center pt-2">
                {[
                  `Hi ${assistantName}, kaise ho aap?`,
                  'Help me build a responsive React app',
                  'Tell me a witty joke',
                  'Search latest AI news for me',
                ].map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => handleSendMessage(prompt)}
                    className="text-xs px-3 py-1.5 rounded-xl border border-purple-800/40 bg-purple-950/30 text-purple-200 hover:bg-purple-900/50 hover:text-white transition-all text-left"
                  >
                    "{prompt}"
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg, index) => {
              const isAssistant = msg.role === 'assistant';

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 sm:gap-4 max-w-3xl ${
                    isAssistant ? 'mr-auto' : 'ml-auto flex-row-reverse'
                  }`}
                >
                  {/* Avatar */}
                  <div className="shrink-0 mt-1">
                    {isAssistant ? (
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-pink-500/20">
                        <Bot className="w-4 h-4" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-pink-400 font-bold text-xs">
                        <User className="w-4 h-4" />
                      </div>
                    )}
                  </div>

                  {/* Message Bubble Container */}
                  <div className={`space-y-2 flex-1 max-w-[85%] sm:max-w-[75%]`}>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-300">
                        {isAssistant ? assistantName : nickname}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    {/* Attached Images */}
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="flex flex-wrap gap-2 pt-1">
                        {msg.attachments.map((att, attIdx) => (
                          <img
                            key={attIdx}
                            src={att.dataUrl || att.url}
                            alt={att.name}
                            className="max-h-48 rounded-xl border border-purple-800/40 object-cover shadow-md"
                          />
                        ))}
                      </div>
                    )}

                    {/* Content Box */}
                    <div
                      className={`p-4 rounded-2xl text-sm leading-relaxed ${
                        isAssistant
                          ? 'bg-slate-900/80 border border-purple-900/40 text-slate-100 backdrop-blur-xl'
                          : 'bg-gradient-to-r from-pink-600/90 to-purple-700/90 text-white shadow-lg shadow-pink-500/10'
                      }`}
                    >
                      {editingMessageId === msg.id ? (
                        <div className="space-y-2">
                          <textarea
                            value={editingContent}
                            onChange={(e) => setEditingContent(e.target.value)}
                            className="w-full p-2 text-xs rounded-xl bg-slate-950 border border-purple-600 text-white focus:outline-none"
                            rows={3}
                          />
                          <div className="flex gap-2 justify-end">
                            <button
                              onClick={() => setEditingMessageId(null)}
                              className="px-2.5 py-1 text-xs text-slate-400 hover:text-white"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => handleSaveEdit(msg.id)}
                              className="px-3 py-1 text-xs rounded-lg bg-pink-500 text-white font-medium"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="whitespace-pre-wrap font-sans break-words space-y-2">
                          {renderFormattedText(msg.content)}
                        </div>
                      )}

                      {/* Action Cards (e.g. Open YouTube, Launch App, etc.) */}
                      {msg.actions && msg.actions.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-white/10 space-y-2">
                          {msg.actions.map((act) => (
                            <div
                              key={act.id}
                              className="p-3 rounded-xl bg-slate-950/60 border border-pink-500/30 flex items-center justify-between"
                            >
                              <div className="flex items-center gap-2">
                                <Zap className="w-4 h-4 text-pink-400" />
                                <div>
                                  <h4 className="text-xs font-bold text-white">{act.title}</h4>
                                  <p className="text-[11px] text-slate-400">{act.description}</p>
                                </div>
                              </div>
                              <button
                                onClick={() => executeActionCard(act)}
                                className="px-3 py-1.5 rounded-lg bg-pink-600 hover:bg-pink-500 text-white text-xs font-medium flex items-center gap-1 shadow-md transition-all"
                              >
                                <span>Execute</span>
                                <ExternalLink className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action Toolbar on Message */}
                    <div
                      className={`flex items-center gap-2 text-slate-400 text-xs px-1 ${
                        isAssistant ? 'justify-start' : 'justify-end'
                      }`}
                    >
                      <button
                        onClick={() => handleCopy(msg.content, msg.id)}
                        title="Copy message"
                        className="hover:text-pink-400 transition-colors p-1"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {isAssistant && (
                        <button
                          onClick={() => speakText(msg.content)}
                          title="Voice playback"
                          className="hover:text-pink-400 transition-colors p-1"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {!isAssistant && (
                        <button
                          onClick={() => {
                            setEditingMessageId(msg.id);
                            setEditingContent(msg.content);
                          }}
                          title="Edit message"
                          className="hover:text-pink-400 transition-colors p-1"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {!isAssistant && index === messages.length - 2 && (
                        <button
                          onClick={() => handleRegenerate(index)}
                          title="Regenerate response"
                          className="hover:text-pink-400 transition-colors p-1"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteMessage(msg.id)}
                        title="Delete message"
                        className="hover:text-red-400 transition-colors p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {/* Thinking / Generating indicator */}
          {isGenerating && (
            <div className="flex items-center gap-3 text-xs text-pink-400 animate-pulse py-2">
              <div className="w-7 h-7 rounded-lg bg-pink-500/20 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-pink-400 animate-spin" />
              </div>
              <span>{assistantName} is thinking & crafting response...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Floating Input Dock */}
        <div className="absolute bottom-16 md:bottom-2 left-0 right-0 p-3 sm:p-4 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent z-20">
          <div className="max-w-3xl mx-auto space-y-2">
            {/* Image Preview Shelf if uploaded */}
            {selectedImages.length > 0 && (
              <div className="flex gap-2 p-2 rounded-xl bg-slate-900/90 border border-purple-800/40">
                {selectedImages.map((img, i) => (
                  <div key={i} className="relative group">
                    <img
                      src={img.base64}
                      alt={img.name}
                      className="w-14 h-14 object-cover rounded-lg border border-purple-500/40"
                    />
                    <button
                      onClick={() =>
                        setSelectedImages((prev) => prev.filter((_, idx) => idx !== i))
                      }
                      className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full p-0.5"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Input Bar */}
            <div className="flex items-center gap-2 p-2 rounded-2xl bg-slate-900/90 border border-purple-800/40 backdrop-blur-2xl shadow-2xl focus-within:border-pink-500/60 transition-all">
              {/* Image upload button */}
              <label
                title="Attach image"
                className="p-2.5 rounded-xl hover:bg-slate-800/80 text-slate-400 hover:text-pink-400 cursor-pointer transition-colors"
              >
                <ImageIcon className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>

              {/* Text Input */}
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={`Message ${assistantName}...`}
                rows={1}
                className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none resize-none px-2 max-h-28"
              />

              {/* Mic Speech-to-Text Button */}
              <button
                type="button"
                onClick={toggleRecording}
                title={isRecording ? 'Stop listening' : 'Speak to input'}
                className={`p-2.5 rounded-xl transition-all ${
                  isRecording
                    ? 'bg-pink-600 text-white animate-pulse shadow-[0_0_15px_rgba(236,72,153,0.6)]'
                    : 'hover:bg-slate-800/80 text-slate-400 hover:text-pink-400'
                }`}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>

              {/* Stop Speaking if active */}
              {isSpeakingAudio && (
                <button
                  type="button"
                  onClick={stopSpeaking}
                  title="Stop audio speech"
                  className="p-2.5 rounded-xl bg-purple-900/60 text-pink-300 hover:bg-purple-800"
                >
                  <VolumeX className="w-4 h-4" />
                </button>
              )}

              {/* Send or Stop Generation */}
              {isGenerating ? (
                <button
                  type="button"
                  onClick={() => setIsGenerating(false)}
                  title="Stop generation"
                  className="p-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white shadow-md active:scale-95 transition-all"
                >
                  <Square className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleSendMessage()}
                  disabled={!inputText.trim() && selectedImages.length === 0}
                  aria-label="Send message"
                  className="p-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 disabled:opacity-40 text-white shadow-lg shadow-pink-500/20 active:scale-95 transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Simple Markdown Formatter Helper
function renderFormattedText(text: string): React.ReactNode {
  if (!text) return null;

  // Split by code blocks ```
  const parts = text.split(/(```[\s\S]*?```)/g);

  return parts.map((part, index) => {
    if (part.startsWith('```') && part.endsWith('```')) {
      const firstLineEnd = part.indexOf('\n');
      const lang = firstLineEnd !== -1 ? part.substring(3, firstLineEnd).trim() : '';
      const code = firstLineEnd !== -1 ? part.substring(firstLineEnd + 1, part.length - 3) : part.substring(3, part.length - 3);

      return (
        <div key={index} className="my-2 rounded-xl overflow-hidden border border-purple-900/40 bg-slate-950 font-mono text-xs">
          <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900/80 border-b border-purple-900/30 text-slate-400">
            <span>{lang || 'code'}</span>
            <button
              onClick={() => navigator.clipboard.writeText(code)}
              className="hover:text-pink-400 text-[11px] flex items-center gap-1"
            >
              <Copy className="w-3 h-3" />
              <span>Copy</span>
            </button>
          </div>
          <pre className="p-3 overflow-x-auto text-emerald-300">
            <code>{code}</code>
          </pre>
        </div>
      );
    }

    return <span key={index}>{part}</span>;
  });
}
