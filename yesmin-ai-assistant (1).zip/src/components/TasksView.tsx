import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { TaskItem } from '../types';
import { getEffectiveAssistantName } from '../utils/personality';
import {
  CheckSquare,
  Plus,
  Trash2,
  Bell,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
} from 'lucide-react';

export const TasksView: React.FC = () => {
  const { settings, triggerNotification, showToast } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPriority, setNewPriority] = useState<TaskItem['priority']>('medium');
  const [newDueDate, setNewDueDate] = useState('');
  const [newReminder, setNewReminder] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      const list = await api.getTasks();
      setTasks(list);
    } catch (err: any) {
      showToast(err.message || 'Error loading tasks', 'error');
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      const task = await api.createTask({
        title: newTitle.trim(),
        description: newDesc.trim(),
        priority: newPriority,
        dueDate: newDueDate || undefined,
        reminder: newReminder,
      });

      setTasks((prev) => [task, ...prev]);
      setNewTitle('');
      setNewDesc('');
      setNewDueDate('');
      setNewReminder(false);
      setIsAdding(false);

      if (newReminder) {
        triggerNotification('Task Reminder Scheduled', `Reminder set for: ${task.title}`);
      }

      showToast('Task added successfully', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to create task', 'error');
    }
  };

  const toggleComplete = async (task: TaskItem) => {
    try {
      const updated = await api.updateTask(task.id, { completed: !task.completed });
      setTasks((prev) => prev.map((t) => (t.id === task.id ? updated : t)));
      showToast(
        !task.completed ? 'Task marked complete! Great job!' : 'Task marked pending',
        'info'
      );
    } catch (err: any) {
      showToast('Failed to update task', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteTask(id);
      setTasks((prev) => prev.filter((t) => t.id !== id));
      showToast('Task removed', 'info');
    } catch (err: any) {
      showToast('Failed to delete task', 'error');
    }
  };

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'pending') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 max-w-4xl mx-auto space-y-6 pb-24 md:pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-emerald-400" />
            Tasks & Proactive Reminders
          </h2>
          <p className="text-xs text-slate-400">
            {assistantName} organizes your daily milestones, reminders, and schedules.
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Task</span>
        </button>
      </div>

      {/* Add Task Form */}
      {isAdding && (
        <form
          onSubmit={handleCreate}
          className="p-5 rounded-3xl bg-slate-900/80 border border-emerald-500/40 backdrop-blur-xl space-y-4 shadow-xl"
        >
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            Add Milestone / Task
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Task Title (e.g. Test Gemini Live Voice Call)"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-emerald-500"
            />

            <input
              type="text"
              placeholder="Description (Optional)"
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-emerald-500"
            />

            <div className="flex gap-2">
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as any)}
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="low">Low Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="high">High Priority</option>
              </select>

              <input
                type="date"
                value={newDueDate}
                onChange={(e) => setNewDueDate(e.target.value)}
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-300 px-2 cursor-pointer">
              <input
                type="checkbox"
                checked={newReminder}
                onChange={(e) => setNewReminder(e.target.checked)}
                className="rounded text-emerald-500"
              />
              <Bell className="w-3.5 h-3.5 text-pink-400" />
              <span>Enable Browser Notification Reminder</span>
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs rounded-xl bg-emerald-600 text-white font-semibold shadow"
            >
              Save Task
            </button>
          </div>
        </form>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 bg-slate-900/60 p-1 rounded-2xl border border-purple-900/30">
          {(['all', 'pending', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1 rounded-xl text-xs capitalize transition-all ${
                filter === tab
                  ? 'bg-emerald-600 text-white font-semibold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-400">
          {filteredTasks.length} {filter} tasks
        </span>
      </div>

      {/* Tasks List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="p-8 rounded-3xl bg-slate-900/40 border border-purple-900/20 text-center text-xs text-slate-500">
            No tasks found in this view.
          </div>
        ) : (
          filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-4 rounded-2xl border backdrop-blur-xl flex items-center justify-between gap-3 transition-all ${
                task.completed
                  ? 'bg-slate-950/40 border-purple-900/20 opacity-60'
                  : 'bg-slate-900/60 border-purple-900/40 hover:border-emerald-500/40'
              }`}
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <button
                  onClick={() => toggleComplete(task)}
                  className="text-emerald-400 hover:scale-110 transition-transform shrink-0"
                >
                  {task.completed ? (
                    <CheckCircle2 className="w-5 h-5 fill-emerald-500/20 text-emerald-400" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-500 hover:text-emerald-400" />
                  )}
                </button>

                <div className="overflow-hidden space-y-0.5">
                  <h4
                    className={`text-xs sm:text-sm font-semibold truncate ${
                      task.completed ? 'line-through text-slate-400' : 'text-white'
                    }`}
                  >
                    {task.title}
                  </h4>
                  {task.description && (
                    <p className="text-[11px] text-slate-400 truncate">{task.description}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span
                  className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full border ${
                    task.priority === 'high'
                      ? 'bg-red-950 text-red-300 border-red-800/40'
                      : task.priority === 'medium'
                      ? 'bg-amber-950 text-amber-300 border-amber-800/40'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {task.priority}
                </span>

                {task.dueDate && (
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 hidden sm:flex">
                    <Calendar className="w-3 h-3 text-slate-500" />
                    {task.dueDate}
                  </span>
                )}

                <button
                  onClick={() => handleDelete(task.id)}
                  title="Delete task"
                  className="p-1 hover:text-red-400 text-slate-500 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
