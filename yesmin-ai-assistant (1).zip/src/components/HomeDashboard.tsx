import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Orb } from './Orb';
import {
  MessageSquare,
  Radio,
  Terminal,
  Zap,
  Search,
  Upload,
  FolderGit2,
  Sparkles,
  ArrowRight,
  Brain,
  CheckCircle2,
  Clock,
  Heart,
  Tablet,
  Download,
} from 'lucide-react';
import { getEffectiveAssistantName, getEffectiveNickname, generateGreeting } from '../utils/personality';
import { api } from '../services/api';
import { Conversation, Project, TaskItem } from '../types';
import { TabletInstallModal } from './TabletInstallModal';

export const HomeDashboard: React.FC = () => {
  const { settings, setActiveTab, setCurrentConversationId, assistantStatus } = useApp();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [quickInput, setQuickInput] = useState('');
  const [showTabletModal, setShowTabletModal] = useState(false);

  const assistantName = getEffectiveAssistantName(settings.assistantName);
  const nickname = getEffectiveNickname(settings.userNickname);

  useEffect(() => {
    async function loadData() {
      try {
        const [convList, projList, taskList] = await Promise.all([
          api.getConversations(),
          api.getProjects(),
          api.getTasks(),
        ]);
        setConversations(convList.slice(0, 4));
        setProjects(projList.slice(0, 3));
        setTasks(taskList.slice(0, 4));
      } catch (err) {
        console.warn('Dashboard data load:', err);
      }
    }
    loadData();
  }, []);

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    // Store quick message in session or query param and navigate to chat
    sessionStorage.setItem('pending_quick_prompt', quickInput.trim());
    setQuickInput('');
    setActiveTab('chat');
  };

  const quickActions = [
    {
      title: 'Start Chat',
      desc: 'Text, voice notes, attachments & files',
      icon: <MessageSquare className="w-5 h-5 text-pink-400" />,
      onClick: () => setActiveTab('chat'),
      gradient: 'from-pink-500/10 hover:from-pink-500/20 to-purple-500/10 border-pink-500/30',
    },
    {
      title: 'Start Live Voice',
      desc: 'Realtime speech call with interruption',
      icon: <Radio className="w-5 h-5 text-purple-400 animate-pulse" />,
      onClick: () => setActiveTab('live'),
      gradient: 'from-purple-500/10 hover:from-purple-500/20 to-indigo-500/10 border-purple-500/30',
    },
    {
      title: 'Open Coding Agent',
      desc: 'AI dev workflow, editor & sandboxed runner',
      icon: <Terminal className="w-5 h-5 text-emerald-400" />,
      onClick: () => setActiveTab('code'),
      gradient: 'from-emerald-500/10 hover:from-emerald-500/20 to-teal-500/10 border-emerald-500/30',
    },
    {
      title: 'Search Web',
      desc: 'Live web searches with source citations',
      icon: <Search className="w-5 h-5 text-cyan-400" />,
      onClick: () => setActiveTab('search'),
      gradient: 'from-cyan-500/10 hover:from-cyan-500/20 to-blue-500/10 border-cyan-500/30',
    },
    {
      title: 'Upload File',
      desc: 'Analyze PDF, DOCX, images & code',
      icon: <Upload className="w-5 h-5 text-amber-400" />,
      onClick: () => setActiveTab('files'),
      gradient: 'from-amber-500/10 hover:from-amber-500/20 to-orange-500/10 border-amber-500/30',
    },
    {
      title: 'Open Projects',
      desc: 'Organized hubs for apps, sites & study',
      icon: <FolderGit2 className="w-5 h-5 text-violet-400" />,
      onClick: () => setActiveTab('projects'),
      gradient: 'from-violet-500/10 hover:from-violet-500/20 to-purple-500/10 border-violet-500/30',
    },
    {
      title: 'Apps & Actions',
      desc: 'YouTube, Maps, WhatsApp & Android bridge',
      icon: <Zap className="w-5 h-5 text-pink-400" />,
      onClick: () => setActiveTab('actions'),
      gradient: 'from-pink-500/10 hover:from-pink-500/20 to-rose-500/10 border-pink-500/30',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 sm:py-8 max-w-6xl mx-auto space-y-8 pb-24 md:pb-12">
      {/* Hero Section with AI Orb and Personalized Greeting */}
      <section className="relative overflow-hidden rounded-3xl border border-purple-900/40 bg-gradient-to-b from-slate-900/90 via-purple-950/30 to-slate-950/90 backdrop-blur-2xl p-6 sm:p-10 shadow-2xl">
        {/* Futuristic background glow circles */}
        <div className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-pink-500/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
          <div className="text-center md:text-left space-y-3 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/20 text-pink-300 text-xs font-semibold">
              <Heart className="w-3.5 h-3.5 text-pink-400 fill-pink-400" />
              <span>{settings.personalityMode === 'girlfriend' ? 'AI Girlfriend & Companion' : 'Personal Jarvis Assistant'}</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
              Hi, <span className="bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">{nickname}</span>
            </h1>

            <p className="text-lg sm:text-xl font-medium text-slate-300 leading-relaxed">
              I'm <span className="text-pink-400 font-bold">{assistantName}</span>. How can I help you today?
            </p>

            <p className="text-xs sm:text-sm text-slate-400">
              Hindi • Hinglish • English conversational support, Gemini Live real-time audio, coding agent & system automations.
            </p>

            {/* Quick input prompt directly from home */}
            <form onSubmit={handleQuickSubmit} className="pt-2 flex items-center gap-2 max-w-md">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder={`Ask ${assistantName} anything...`}
                  value={quickInput}
                  onChange={(e) => setQuickInput(e.target.value)}
                  className="w-full pl-4 pr-10 py-3 rounded-2xl bg-slate-950/80 border border-purple-800/40 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-pink-500/60 shadow-inner"
                />
              </div>
              <button
                type="submit"
                aria-label={`Send message to ${assistantName}`}
                className="px-4 py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-medium shadow-lg shadow-pink-500/20 active:scale-95 transition-all"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Central Animated Orb */}
          <div className="flex flex-col items-center">
            <Orb size="lg" status={assistantStatus} onClick={() => setActiveTab('live')} />
            <p className="text-[11px] text-slate-400 mt-2">Tap orb to enter Live Voice</p>
          </div>
        </div>
      </section>

      {/* Galaxy Tab A7 Lite Installation Callout Banner */}
      <section className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-purple-950/60 via-pink-950/40 to-slate-900/80 border border-pink-500/30 backdrop-blur-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-lg shadow-pink-500/30 shrink-0">
            <Tablet className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white">
                Samsung Galaxy Tab A7 Lite Edition
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40 animate-pulse">
                Android Ready
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              1-Click me apne tablet par standalone app ki tarah install karein bina URL bar ke.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/api/download-zip"
            download="yesmin-ai-assistant.zip"
            className="px-4 py-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-emerald-500/40 text-emerald-300 font-bold text-xs shadow-lg flex items-center gap-2 active:scale-95 transition-all shrink-0"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Download .ZIP File</span>
          </a>

          <button
            onClick={() => setShowTabletModal(true)}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 text-white font-bold text-xs shadow-lg shadow-pink-500/30 flex items-center gap-2 active:scale-95 transition-all shrink-0"
          >
            <Tablet className="w-4 h-4" />
            <span>Install on Galaxy Tab</span>
          </button>
        </div>
      </section>

      {/* Quick Action Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-400" />
            Quick Actions
          </h2>
          <span className="text-xs text-slate-400">7 Core Modules</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {quickActions.map((action, i) => (
            <button
              key={i}
              onClick={action.onClick}
              className={`p-4 rounded-2xl border text-left bg-gradient-to-br ${action.gradient} backdrop-blur-xl transition-all duration-200 hover:scale-[1.02] hover:shadow-lg active:scale-95 flex items-start gap-3.5 group`}
            >
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-white/5 shadow-inner group-hover:scale-110 transition-transform">
                {action.icon}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white group-hover:text-pink-300 transition-colors">
                  {action.title}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{action.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Recents: Conversations & Active Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Conversations */}
        <div className="rounded-3xl border border-purple-900/30 bg-slate-900/50 backdrop-blur-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-400" />
              Recent Conversations
            </h3>
            <button
              onClick={() => setActiveTab('chat')}
              className="text-xs text-pink-400 hover:text-pink-300 font-medium flex items-center gap-1"
            >
              Open Chat <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2">
            {conversations.length === 0 ? (
              <p className="text-xs text-slate-500 py-3 text-center">No conversation history yet.</p>
            ) : (
              conversations.map((c) => (
                <div
                  key={c.id}
                  onClick={() => {
                    setCurrentConversationId(c.id);
                    setActiveTab('chat');
                  }}
                  className="p-3 rounded-xl border border-purple-900/20 bg-slate-950/40 hover:bg-slate-900/80 cursor-pointer flex items-center justify-between group transition-all"
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <MessageSquare className="w-3.5 h-3.5 text-slate-400 group-hover:text-pink-400 transition-colors shrink-0" />
                    <span className="text-xs text-slate-200 group-hover:text-white truncate font-medium">
                      {c.title}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 shrink-0">
                    {new Date(c.updatedAt).toLocaleDateString()}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Active Workspace Projects */}
        <div className="rounded-3xl border border-purple-900/30 bg-slate-900/50 backdrop-blur-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FolderGit2 className="w-4 h-4 text-emerald-400" />
              Active Projects
            </h3>
            <button
              onClick={() => setActiveTab('projects')}
              className="text-xs text-pink-400 hover:text-pink-300 font-medium flex items-center gap-1"
            >
              All Projects <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2">
            {projects.length === 0 ? (
              <p className="text-xs text-slate-500 py-3 text-center">No active projects created yet.</p>
            ) : (
              projects.map((p) => (
                <div
                  key={p.id}
                  onClick={() => setActiveTab('projects')}
                  className="p-3 rounded-xl border border-purple-900/20 bg-slate-950/40 hover:bg-slate-900/80 cursor-pointer flex items-center justify-between group transition-all"
                >
                  <div className="overflow-hidden">
                    <h4 className="text-xs font-semibold text-slate-200 group-hover:text-white truncate">
                      {p.name}
                    </h4>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{p.description || 'Workspace project'}</p>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium shrink-0">
                    {p.files?.length || 1} files
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <TabletInstallModal
        isOpen={showTabletModal}
        onClose={() => setShowTabletModal(false)}
      />
    </div>
  );
};
