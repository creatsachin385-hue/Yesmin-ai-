import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { ProjectFile } from '../types';
import { getEffectiveAssistantName } from '../utils/personality';
import {
  Terminal,
  Play,
  FileCode,
  FolderTree,
  Plus,
  Trash2,
  Edit3,
  Download,
  Sparkles,
  Bug,
  RefreshCw,
  Eye,
  CheckCircle2,
  AlertTriangle,
  Code2,
} from 'lucide-react';

const initialFiles: ProjectFile[] = [
  {
    id: 'f_index',
    name: 'index.html',
    path: 'index.html',
    language: 'html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Yesmin AI App</title>
  <style>
    body { background: #0b0d1b; color: #fff; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
    .card { background: rgba(255,255,255,0.05); border: 1px solid rgba(236,72,153,0.3); border-radius: 16px; padding: 24px; text-align: center; box-shadow: 0 0 30px rgba(236,72,153,0.2); }
    h1 { color: #f472b6; margin-bottom: 8px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Hello from Yesmin Coding Agent</h1>
    <p>Realtime sandboxed editor & autonomous code runner</p>
  </div>
</body>
</html>`,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'f_app_js',
    name: 'app.js',
    path: 'app.js',
    language: 'javascript',
    content: `// Autonomous Javascript Sandbox Runner
function calculateStats(items) {
  const sum = items.reduce((acc, curr) => acc + curr, 0);
  const avg = sum / items.length;
  return { sum, avg, count: items.length };
}

const sampleData = [12, 45, 78, 23, 90, 56];
const stats = calculateStats(sampleData);
console.log("Execution Output:");
console.log("Count:", stats.count);
console.log("Sum:", stats.sum);
console.log("Average:", stats.avg.toFixed(2));
`,
    updatedAt: new Date().toISOString(),
  },
];

export const CodingAgentView: React.FC = () => {
  const { settings, showToast } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const [files, setFiles] = useState<ProjectFile[]>(initialFiles);
  const [activeFileId, setActiveFileId] = useState<string>(initialFiles[1].id);
  const [userPrompt, setUserPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [agentStep, setAgentStep] = useState<string>('Ready for prompt');
  const [terminalLogs, setTerminalLogs] = useState<string>('[Sandbox Terminal Ready]\nClick "Run in Sandbox" or ask the agent to build any feature.');
  const [activeViewTab, setActiveViewTab] = useState<'editor' | 'terminal' | 'preview'>('editor');
  const [newFileName, setNewFileName] = useState('');
  const [showNewFileModal, setShowNewFileModal] = useState(false);

  const activeFile = files.find((f) => f.id === activeFileId) || files[0];

  const handleCodeChange = (newContent: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === activeFileId ? { ...f, content: newContent, updatedAt: new Date().toISOString() } : f))
    );
  };

  const handleCreateFile = () => {
    if (!newFileName.trim()) return;
    const name = newFileName.trim();
    const ext = name.split('.').pop() || 'js';
    const lang = ext === 'html' ? 'html' : ext === 'css' ? 'css' : ext === 'json' ? 'json' : 'javascript';

    const newF: ProjectFile = {
      id: `f_${Date.now()}`,
      name,
      path: name,
      language: lang,
      content: `// New file: ${name}\n`,
      updatedAt: new Date().toISOString(),
    };

    setFiles((prev) => [...prev, newF]);
    setActiveFileId(newF.id);
    setNewFileName('');
    setShowNewFileModal(false);
    showToast(`File created: ${name}`, 'success');
  };

  const handleDeleteFile = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (files.length <= 1) {
      showToast('Cannot delete the last remaining file', 'warning');
      return;
    }
    const remaining = files.filter((f) => f.id !== id);
    setFiles(remaining);
    if (activeFileId === id) {
      setActiveFileId(remaining[0].id);
    }
    showToast('File deleted', 'info');
  };

  // Run code safely in backend sandbox
  const handleRunSandbox = async () => {
    setActiveViewTab('terminal');
    setTerminalLogs('[Sandbox Engine] Starting execution in isolated container...\n');

    try {
      const result = await api.runSandboxCode(activeFile.content, activeFile.language);
      let logOutput = `[Execution Completed] Exit Code: ${result.exitCode ?? (result.success ? 0 : 1)}\n\n`;

      if (result.stdout) {
        logOutput += `--- STDOUT ---\n${result.stdout}\n`;
      }
      if (result.stderr) {
        logOutput += `\n--- STDERR / ERRORS ---\n${result.stderr}\n`;
      }
      if (result.error) {
        logOutput += `\n--- SYSTEM ERROR ---\n${result.error}\n`;
      }

      setTerminalLogs(logOutput);
      showToast(result.success ? 'Execution succeeded' : 'Execution finished with warnings/errors', result.success ? 'success' : 'warning');
    } catch (err: any) {
      setTerminalLogs(`[Sandbox Error] ${err.message || 'Execution failed'}`);
      showToast('Sandbox execution error', 'error');
    }
  };

  // AI Autonomous Coding Agent Flow
  const handleAgentPrompt = async () => {
    if (!userPrompt.trim()) return;
    setIsProcessing(true);

    try {
      // Step 1: Planner
      setAgentStep('Step 1/4: Analyzing project structure & planning code...');
      const projectSummary = files.map((f) => `File: ${f.name} (${f.language})`).join(', ');

      const prompt = `You are ${assistantName}, a senior software engineer and autonomous coding agent.
Current Files: ${projectSummary}
Currently active file: ${activeFile.name}
Current code of ${activeFile.name}:
\`\`\`${activeFile.language}
${activeFile.content}
\`\`\`

USER REQUEST: "${userPrompt}"

Please fulfill the request. If you are modifying the active file, output the updated full code in a markdown code block (\`\`\`${activeFile.language} ... \`\`\`).
Explain what changes were made concisely.`;

      // Step 2: Generation
      setAgentStep('Step 2/4: Generating production-ready code & architecture...');
      const response = await api.generateChat({
        prompt,
      });

      // Step 3: Extract code from response
      setAgentStep('Step 3/4: Inspecting code syntax and updating file...');
      const codeMatch = response.match(/```[a-zA-Z]*\n([\s\S]*?)```/);
      if (codeMatch && codeMatch[1]) {
        const generatedCode = codeMatch[1];
        handleCodeChange(generatedCode);
        showToast(`Updated ${activeFile.name} with AI modifications`, 'success');
      }

      // Step 4: Run sandboxed verification
      setAgentStep('Step 4/4: Running code in sandbox verification...');
      const runResult = await api.runSandboxCode(activeFile.content, activeFile.language);
      setTerminalLogs(
        `[Coding Agent Analysis for: "${userPrompt}"]\n\nAI Explanation:\n${response.replace(/```[\s\S]*?```/g, '')}\n\n[Sandbox Test Run]\nSTDOUT: ${runResult.stdout || 'None'}\nSTDERR: ${runResult.stderr || 'Clean, no errors'}`
      );

      setAgentStep('Completed successfully');
      setUserPrompt('');
    } catch (err: any) {
      showToast(err.message || 'Agent failed to complete task', 'error');
      setAgentStep('Failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // AI Fix Errors
  const handleFixErrors = async () => {
    setIsProcessing(true);
    setAgentStep('Analyzing terminal errors & generating fix...');

    try {
      const prompt = `The following code in ${activeFile.name} produced errors during sandboxed execution:
\`\`\`${activeFile.language}
${activeFile.content}
\`\`\`

TERMINAL OUTPUT:
${terminalLogs}

Please fix the errors and return the corrected complete code in a markdown block.`;

      const response = await api.generateChat({ prompt });
      const codeMatch = response.match(/```[a-zA-Z]*\n([\s\S]*?)```/);
      if (codeMatch && codeMatch[1]) {
        handleCodeChange(codeMatch[1]);
        showToast('Errors analyzed and fixed', 'success');
      }
      setTerminalLogs(`[AI Auto-Fix Applied]\n${response}`);
    } catch (err: any) {
      showToast('Could not fix errors', 'error');
    } finally {
      setIsProcessing(false);
      setAgentStep('Ready');
    }
  };

  const handleExportZip = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(files, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'project-bundle.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Exported project bundle JSON', 'success');
  };

  // Generate live iframe HTML
  const generatePreviewHtml = () => {
    const htmlFile = files.find((f) => f.name.endsWith('.html'));
    const jsFile = files.find((f) => f.name.endsWith('.js'));
    const cssFile = files.find((f) => f.name.endsWith('.css'));

    let html = htmlFile?.content || '<h3>No HTML file found</h3>';
    if (cssFile) {
      html = html.replace('</head>', `<style>${cssFile.content}</style></head>`);
    }
    if (jsFile) {
      html = html.replace('</body>', `<script>${jsFile.content}</script></body>`);
    }
    return html;
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950 pb-20 md:pb-0">
      {/* Top Coding Agent Prompt Bar */}
      <div className="border-b border-purple-900/30 bg-slate-900/70 backdrop-blur-xl p-3 sm:p-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="flex-1 flex items-center gap-2 bg-slate-950/80 border border-purple-800/40 rounded-xl px-3 py-1.5 focus-within:border-pink-500/60">
            <Sparkles className="w-4 h-4 text-pink-400 shrink-0" />
            <input
              type="text"
              placeholder={`Tell ${assistantName} what to code (e.g. "Create a login form" or "Write a binary search algorithm")...`}
              value={userPrompt}
              onChange={(e) => setUserPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAgentPrompt()}
              className="w-full bg-transparent text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAgentPrompt}
              disabled={isProcessing || !userPrompt.trim()}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 disabled:opacity-40 text-white text-xs font-semibold shadow-md active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Code2 className="w-4 h-4" />
              <span>{isProcessing ? 'Agent Working...' : 'Run Agent'}</span>
            </button>

            <button
              onClick={handleRunSandbox}
              title="Run current code in isolated sandbox"
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Run Sandbox</span>
            </button>

            <button
              onClick={handleExportZip}
              title="Export project"
              className="p-2 rounded-xl border border-slate-800 bg-slate-900/80 hover:bg-slate-800 text-slate-300 transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Status / Planner progress line */}
        {isProcessing && (
          <div className="mt-2 text-xs text-pink-400 flex items-center gap-2 animate-pulse">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>{agentStep}</span>
          </div>
        )}
      </div>

      {/* Main Workspace: File Explorer + Editor / Terminal / Preview */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Files Sidebar */}
        <div className="w-56 shrink-0 border-r border-purple-900/30 bg-slate-950/80 p-3 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <FolderTree className="w-3.5 h-3.5" />
                Files
              </span>
              <button
                onClick={() => setShowNewFileModal(true)}
                title="Create new file"
                className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-pink-400 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* File List */}
            <div className="space-y-1">
              {files.map((file) => {
                const isActive = file.id === activeFileId;
                return (
                  <div
                    key={file.id}
                    onClick={() => setActiveFileId(file.id)}
                    className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs cursor-pointer transition-all ${
                      isActive
                        ? 'bg-pink-500/20 text-white font-medium border-l-2 border-pink-500'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileCode className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                      <span className="truncate">{file.name}</span>
                    </div>

                    <button
                      onClick={(e) => handleDeleteFile(file.id, e)}
                      title="Delete file"
                      className="opacity-0 group-hover:opacity-100 hover:text-red-400 p-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick AI Assistance Actions */}
          <div className="space-y-1.5 pt-3 border-t border-purple-900/30">
            <button
              onClick={handleFixErrors}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs text-amber-300 hover:bg-amber-950/30 border border-amber-500/20 transition-colors"
            >
              <Bug className="w-3.5 h-3.5 text-amber-400" />
              <span>Fix Terminal Errors</span>
            </button>
          </div>
        </div>

        {/* Right Editor & Views Area */}
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
          {/* Tabs bar: Code Editor | Terminal / Logs | Web Preview */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-purple-900/30 bg-slate-900/60">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveViewTab('editor')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  activeViewTab === 'editor'
                    ? 'bg-pink-500/20 text-pink-300 border border-pink-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>{activeFile.name}</span>
              </button>

              <button
                onClick={() => setActiveViewTab('terminal')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  activeViewTab === 'terminal'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Sandbox Terminal</span>
              </button>

              <button
                onClick={() => setActiveViewTab('preview')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  activeViewTab === 'preview'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Live Preview</span>
              </button>
            </div>

            <span className="text-[11px] text-slate-500">
              Language: {activeFile.language}
            </span>
          </div>

          {/* Tab Contents */}
          <div className="flex-1 overflow-hidden relative">
            {activeViewTab === 'editor' && (
              <div className="h-full flex overflow-auto">
                <textarea
                  value={activeFile.content}
                  onChange={(e) => handleCodeChange(e.target.value)}
                  spellCheck={false}
                  className="w-full h-full p-4 font-mono text-xs sm:text-sm bg-slate-950 text-slate-100 focus:outline-none resize-none leading-relaxed border-none selection:bg-pink-500/30"
                />
              </div>
            )}

            {activeViewTab === 'terminal' && (
              <div className="h-full p-4 font-mono text-xs overflow-auto bg-black text-emerald-400 space-y-2 select-text">
                <pre className="whitespace-pre-wrap">{terminalLogs}</pre>
              </div>
            )}

            {activeViewTab === 'preview' && (
              <div className="w-full h-full bg-white">
                <iframe
                  title="Live Sandbox Preview"
                  srcDoc={generatePreviewHtml()}
                  sandbox="allow-scripts"
                  className="w-full h-full border-none"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* New File Modal */}
      {showNewFileModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-purple-800/60 p-5 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-white">Create New File</h3>
            <input
              type="text"
              placeholder="e.g. utils.js, styles.css, script.py"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-pink-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowNewFileModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateFile}
                className="px-4 py-1.5 text-xs rounded-xl bg-pink-600 text-white font-semibold"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
