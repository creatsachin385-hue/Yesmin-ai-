import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Orb } from './Orb';
import { LiveAudioManager } from '../services/liveAudio';
import { getEffectiveAssistantName, getEffectiveNickname } from '../utils/personality';
import {
  Mic,
  MicOff,
  PhoneOff,
  Radio,
  Settings,
  Volume2,
  VolumeX,
  Sparkles,
  AlertCircle,
  RotateCcw,
  Hand,
} from 'lucide-react';

export const LiveVoiceView: React.FC = () => {
  const { settings, updateSettings, setActiveTab, showToast, setAssistantStatus } = useApp();

  const [connectionState, setConnectionState] = useState<
    'idle' | 'connecting' | 'connected' | 'speaking' | 'listening' | 'error'
  >('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [transcriptLog, setTranscriptLog] = useState<{ role: string; text: string }[]>([]);
  const [interruptionCount, setInterruptionCount] = useState(0);

  const assistantName = getEffectiveAssistantName(settings.assistantName);
  const nickname = getEffectiveNickname(settings.userNickname);

  const liveAudioRef = useRef<LiveAudioManager | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      endLiveSession();
    };
  }, []);

  const startLiveSession = async () => {
    setErrorMessage(null);
    setConnectionState('connecting');

    try {
      const audioManager = new LiveAudioManager();
      liveAudioRef.current = audioManager;

      // 1. Establish WebSocket to backend live bridge
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/live-ws`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = async () => {
        setConnectionState('connected');
        showToast(`Connected to ${assistantName} in Live Voice`, 'success');

        // 2. Start microphone capture at 16kHz PCM
        try {
          await audioManager.startInput((pcmBase64) => {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'audio', audio: pcmBase64 }));
            }
          });
          setConnectionState('listening');
          setAssistantStatus('listening');
        } catch (micErr: any) {
          console.error('Microphone access denied:', micErr);
          setErrorMessage('Microphone permission required for Live Voice call.');
          setConnectionState('error');
          showToast('Please grant microphone permission', 'warning');
        }
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === 'connected') {
            setConnectionState('listening');
          } else if (data.type === 'audio' && data.audio) {
            // Receive 24kHz PCM from Gemini Live
            setConnectionState('speaking');
            setAssistantStatus('speaking');
            audioManager.playChunk(data.audio);
          } else if (data.type === 'interrupted') {
            // Interruption detected by Gemini
            audioManager.interrupt();
            setInterruptionCount((prev) => prev + 1);
            setConnectionState('listening');
            setAssistantStatus('listening');
          } else if (data.type === 'turn_complete') {
            setConnectionState('listening');
            setAssistantStatus('listening');
          } else if (data.type === 'error') {
            setErrorMessage(data.error);
            setConnectionState('error');
            showToast(data.error, 'error');
          }
        } catch (err) {
          console.error('WS parse error:', err);
        }
      };

      ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        setErrorMessage('Live connection failed. Check your network or GEMINI_API_KEY in Settings.');
        setConnectionState('error');
      };

      ws.onclose = () => {
        if (connectionState !== 'idle') {
          setConnectionState('idle');
          setAssistantStatus('idle');
        }
      };
    } catch (err: any) {
      console.error('Start live failed:', err);
      setErrorMessage(err.message || 'Could not start Live Voice');
      setConnectionState('error');
    }
  };

  const handleInterrupt = () => {
    if (liveAudioRef.current) {
      liveAudioRef.current.interrupt();
    }
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text: '...' }));
    }
    setInterruptionCount((prev) => prev + 1);
    setConnectionState('listening');
    setAssistantStatus('listening');
    showToast('Spoken interruption dispatched', 'info');
  };

  const toggleMute = () => {
    if (liveAudioRef.current) {
      const nextMute = !isMuted;
      liveAudioRef.current.setMuted(nextMute);
      setIsMuted(nextMute);
      showToast(nextMute ? 'Microphone muted' : 'Microphone unmuted', 'info');
    }
  };

  const endLiveSession = () => {
    if (liveAudioRef.current) {
      liveAudioRef.current.stopAll();
      liveAudioRef.current = null;
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    setConnectionState('idle');
    setAssistantStatus('idle');
    setIsMuted(false);
  };

  const changeLanguage = (lang: 'hindi' | 'hinglish' | 'english') => {
    updateSettings({ language: lang });
    showToast(`Live language updated to ${lang.toUpperCase()}`, 'info');
  };

  const statusOrbState =
    connectionState === 'speaking'
      ? 'speaking'
      : connectionState === 'listening'
      ? 'listening'
      : connectionState === 'connecting'
      ? 'thinking'
      : 'idle';

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto px-4 py-6 sm:px-8 max-w-4xl mx-auto items-center justify-between space-y-6 pb-24 md:pb-12">
      {/* Top Banner: Connection Status & Identity */}
      <div className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Radio className="w-5 h-5 text-pink-400 animate-pulse" />
            {connectionState !== 'idle' && connectionState !== 'error' && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Gemini Live Voice • {assistantName}
            </h2>
            <p className="text-[11px] text-slate-400">
              Real-time conversational duplex audio streaming (24kHz model out / 16kHz mic in)
            </p>
          </div>
        </div>

        {/* Language Pill Selector */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-purple-900/40 text-xs">
          {(['hinglish', 'hindi', 'english'] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => changeLanguage(lang)}
              className={`px-2.5 py-1 rounded-lg capitalize transition-all ${
                settings.language === lang
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white font-semibold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {/* Main Visual Arena: Big Animated AI Orb + Waveform */}
      <div className="flex flex-col items-center justify-center my-auto space-y-8 w-full max-w-lg">
        {/* Animated Orb */}
        <div className="relative">
          <Orb size="xl" status={statusOrbState} showStatusLabel={false} />

          {/* Glowing pulse rings during active speech */}
          {connectionState === 'speaking' && (
            <div className="absolute inset-0 rounded-full border-2 border-pink-500/40 animate-ping pointer-events-none" />
          )}
        </div>

        {/* Live Status Label */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/80 border border-purple-800/40 shadow-inner">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                connectionState === 'speaking'
                  ? 'bg-pink-400 animate-ping'
                  : connectionState === 'listening'
                  ? 'bg-emerald-400 animate-pulse'
                  : connectionState === 'connecting'
                  ? 'bg-cyan-400 animate-spin'
                  : connectionState === 'error'
                  ? 'bg-red-400'
                  : 'bg-slate-500'
              }`}
            />
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              {connectionState === 'idle'
                ? 'Ready to Connect'
                : connectionState === 'connecting'
                ? 'Establishing Secure Live Session...'
                : connectionState === 'speaking'
                ? `${assistantName} is Speaking`
                : connectionState === 'listening'
                ? `Listening to ${nickname}...`
                : 'Connection Notice'}
            </span>
          </div>

          <p className="text-xs text-slate-400 max-w-sm">
            {connectionState === 'idle'
              ? 'Press Start Live to begin instant real-time conversation. You can speak freely or interrupt anytime.'
              : connectionState === 'listening'
              ? 'Go ahead, speak in Hindi, Hinglish, or English. Yesmin responds in real-time.'
              : connectionState === 'speaking'
              ? 'Audio playing through 24kHz stream. Tap "Interrupt" or simply speak to stop.'
              : ''}
          </p>
        </div>

        {/* Audio Waveform Visualizer simulation */}
        {connectionState !== 'idle' && connectionState !== 'error' && (
          <div className="flex items-center justify-center gap-1.5 h-12 w-full px-6 py-2 rounded-2xl bg-slate-900/40 border border-purple-900/20 backdrop-blur-md">
            {[40, 70, 30, 90, 60, 100, 50, 80, 45, 95, 35, 85, 55, 75, 40].map((h, i) => (
              <span
                key={i}
                className={`w-1 rounded-full transition-all duration-150 ${
                  connectionState === 'speaking'
                    ? 'bg-gradient-to-t from-pink-500 to-purple-400'
                    : isMuted
                    ? 'bg-slate-700'
                    : 'bg-emerald-400'
                }`}
                style={{
                  height:
                    connectionState === 'speaking'
                      ? `${Math.max(15, (h * Math.sin(Date.now() / 200 + i)) % 40 + 15)}px`
                      : !isMuted
                      ? `${Math.max(8, (h * 0.4) % 24 + 8)}px`
                      : '4px',
                }}
              />
            ))}
          </div>
        )}

        {/* Error message card */}
        {errorMessage && (
          <div className="w-full p-4 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-start gap-3">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold">{errorMessage}</p>
              <p className="text-red-300/80">
                Ensure GEMINI_API_KEY is configured in Secrets and microphone permission is allowed in your browser.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Control Buttons Dock */}
      <div className="flex flex-wrap items-center justify-center gap-4 w-full">
        {connectionState === 'idle' || connectionState === 'error' ? (
          <button
            onClick={startLiveSession}
            className="flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white font-bold text-base shadow-[0_0_30px_rgba(236,72,153,0.4)] active:scale-95 transition-all"
          >
            <Radio className="w-5 h-5 animate-pulse" />
            <span>Start Live Voice</span>
          </button>
        ) : (
          <>
            {/* Mute Toggle */}
            <button
              onClick={toggleMute}
              className={`flex items-center gap-2 px-5 py-3.5 rounded-2xl border text-sm font-semibold transition-all ${
                isMuted
                  ? 'bg-red-950/60 border-red-500/50 text-red-300'
                  : 'bg-slate-900/80 border-slate-700 text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isMuted ? <MicOff className="w-4 h-4 text-red-400" /> : <Mic className="w-4 h-4 text-emerald-400" />}
              <span>{isMuted ? 'Unmute' : 'Mute'}</span>
            </button>

            {/* Manual Interrupt Button */}
            <button
              onClick={handleInterrupt}
              disabled={connectionState !== 'speaking'}
              className="flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-purple-900/50 hover:bg-purple-800 border border-purple-600/40 text-purple-200 text-sm font-semibold disabled:opacity-40 transition-all active:scale-95"
            >
              <Hand className="w-4 h-4 text-pink-400" />
              <span>Interrupt</span>
            </button>

            {/* End Call Button */}
            <button
              onClick={endLiveSession}
              className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white text-sm font-bold shadow-lg shadow-red-600/30 active:scale-95 transition-all"
            >
              <PhoneOff className="w-4 h-4" />
              <span>End Call</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};
