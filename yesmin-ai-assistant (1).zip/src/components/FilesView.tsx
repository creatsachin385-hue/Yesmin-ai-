import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { getEffectiveAssistantName } from '../utils/personality';
import {
  FileText,
  Upload,
  Image as ImageIcon,
  Sparkles,
  CheckCircle2,
  Trash2,
  Eye,
  MessageSquare,
  FileCode,
  Download,
} from 'lucide-react';

interface UploadedDocument {
  id: string;
  name: string;
  type: string;
  size: number;
  content: string;
  isImage: boolean;
  base64?: string;
  summary?: string;
}

export const FilesView: React.FC = () => {
  const { settings, setActiveTab, showToast } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const [filesList, setFilesList] = useState<UploadedDocument[]>([
    {
      id: 'doc_1',
      name: 'system-specifications.txt',
      type: 'text/plain',
      size: 1420,
      content: `YESMIN AI & JARVIS ARCHITECTURE SPECIFICATION\n- Multi-modal intelligence engine with low-latency streaming\n- Dual voice pipelines: Gemini Live (PCM 16k/24k) & ElevenLabs TTS\n- Autonomous coding agent with sandboxed runner\n- Extensible Android companion bridge\n- Persistent database for memory and session states`,
      isImage: false,
    },
  ]);

  const [activeFileId, setActiveFileId] = useState<string>('doc_1');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  const activeDoc = filesList.find((f) => f.id === activeFileId) || filesList[0];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImg = file.type.startsWith('image/');

      const reader = new FileReader();
      if (isImg) {
        reader.onload = () => {
          const newDoc: UploadedDocument = {
            id: `doc_${Date.now()}_${i}`,
            name: file.name,
            type: file.type,
            size: file.size,
            content: `Image file: ${file.name} (${file.type})`,
            isImage: true,
            base64: reader.result as string,
          };
          setFilesList((prev) => [newDoc, ...prev]);
          setActiveFileId(newDoc.id);
          showToast(`Uploaded image: ${file.name}`, 'success');
        };
        reader.readAsDataURL(file);
      } else {
        reader.onload = () => {
          const content = (reader.result as string) || '';
          const newDoc: UploadedDocument = {
            id: `doc_${Date.now()}_${i}`,
            name: file.name,
            type: file.type || 'text/plain',
            size: file.size,
            content: content.slice(0, 50000), // First 50k chars
            isImage: false,
          };
          setFilesList((prev) => [newDoc, ...prev]);
          setActiveFileId(newDoc.id);
          showToast(`Uploaded document: ${file.name}`, 'success');
        };
        reader.readAsText(file);
      }
    }

    e.target.value = '';
  };

  const handleAnalyze = async (mode: 'summary' | 'extract' | 'code' | 'image') => {
    if (!activeDoc) return;
    setAnalyzing(true);
    setAnalysisResult(null);

    try {
      let prompt = '';
      let images: any[] = [];

      if (activeDoc.isImage && activeDoc.base64) {
        prompt = `Analyze this image in detail:
1. Describe visible UI, layout, typography, or elements.
2. Read and transcribe any visible text (OCR).
3. Identify errors, bugs, or UX improvements if applicable.`;
        images = [{ base64: activeDoc.base64, mimeType: activeDoc.type }];
      } else {
        if (mode === 'summary') {
          prompt = `Provide a structured summary of this document ("${activeDoc.name}"):\n\n${activeDoc.content.slice(0, 15000)}`;
        } else if (mode === 'extract') {
          prompt = `Extract all key entities, facts, bullet points, and actionable takeaways from:\n\n${activeDoc.content.slice(0, 15000)}`;
        } else if (mode === 'code') {
          prompt = `Analyze the logic in this document and generate clean, production-ready code implementing its concepts:\n\n${activeDoc.content.slice(0, 15000)}`;
        }
      }

      const response = await api.generateChat({ prompt, images });
      setAnalysisResult(response);
      showToast('Document analyzed successfully', 'success');
    } catch (err: any) {
      showToast(err.message || 'Analysis error', 'error');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleAskInChat = () => {
    if (!activeDoc) return;
    const prompt = `Let's discuss my uploaded file "${activeDoc.name}":\n${activeDoc.content.slice(0, 2000)}`;
    sessionStorage.setItem('pending_quick_prompt', prompt);
    setActiveTab('chat');
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 max-w-6xl mx-auto space-y-6 pb-24 md:pb-12">
      {/* Header & Upload Card */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            Files & Multimodal Document Intelligence
          </h2>
          <p className="text-xs text-slate-400">
            Upload text, PDF, DOCX, code files, and images for OCR, UI critique, and extraction.
          </p>
        </div>

        <label className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 text-white text-xs font-semibold shadow-lg shadow-amber-500/20 cursor-pointer active:scale-95 transition-all">
          <Upload className="w-4 h-4" />
          <span>Upload File or Image</span>
          <input
            type="file"
            multiple
            accept=".txt,.pdf,.docx,.json,.js,.ts,.html,.css,.py,.md,image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </label>
      </div>

      {/* Main Grid: File Explorer + Inspector / AI Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Files Shelf */}
        <div className="lg:col-span-1 rounded-3xl bg-slate-900/50 border border-purple-900/30 p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Uploaded Documents ({filesList.length})
          </h3>

          <div className="space-y-1.5 max-h-96 overflow-y-auto pr-1">
            {filesList.map((f) => {
              const isActive = f.id === activeFileId;
              return (
                <div
                  key={f.id}
                  onClick={() => {
                    setActiveFileId(f.id);
                    setAnalysisResult(null);
                  }}
                  className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between group ${
                    isActive
                      ? 'bg-pink-500/20 border-pink-500/40 text-white'
                      : 'bg-slate-950/40 border-purple-900/20 text-slate-300 hover:bg-slate-900/80'
                  }`}
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    {f.isImage ? (
                      <ImageIcon className="w-4 h-4 text-pink-400 shrink-0" />
                    ) : (
                      <FileText className="w-4 h-4 text-amber-400 shrink-0" />
                    )}
                    <div className="overflow-hidden">
                      <h4 className="text-xs font-semibold truncate">{f.name}</h4>
                      <p className="text-[10px] text-slate-500">{(f.size / 1024).toFixed(1)} KB</p>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setFilesList((prev) => prev.filter((item) => item.id !== f.id));
                    }}
                    className="opacity-0 group-hover:opacity-100 hover:text-red-400 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Content Viewer & AI Analysis Panel */}
        <div className="lg:col-span-2 space-y-4">
          {activeDoc ? (
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-purple-900/30">
                <div>
                  <h3 className="text-base font-bold text-white">{activeDoc.name}</h3>
                  <span className="text-[11px] text-slate-400 font-mono">{activeDoc.type}</span>
                </div>

                {/* AI Action Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  {activeDoc.isImage ? (
                    <button
                      onClick={() => handleAnalyze('image')}
                      disabled={analyzing}
                      className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Analyzing Image...' : 'AI Image Analysis / OCR'}</span>
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => handleAnalyze('summary')}
                        disabled={analyzing}
                        className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Summarize</span>
                      </button>
                      <button
                        onClick={() => handleAnalyze('extract')}
                        disabled={analyzing}
                        className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold"
                      >
                        Extract Data
                      </button>
                    </>
                  )}

                  <button
                    onClick={handleAskInChat}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Ask {assistantName}</span>
                  </button>
                </div>
              </div>

              {/* Preview */}
              {activeDoc.isImage && activeDoc.base64 ? (
                <div className="max-h-80 overflow-hidden rounded-2xl border border-purple-900/40 bg-black/60 flex items-center justify-center p-2">
                  <img src={activeDoc.base64} alt="Preview" className="max-h-72 object-contain rounded-xl" />
                </div>
              ) : (
                <div className="max-h-64 overflow-y-auto p-4 rounded-2xl bg-slate-950 font-mono text-xs text-slate-300 leading-relaxed border border-purple-900/20">
                  <pre className="whitespace-pre-wrap">{activeDoc.content}</pre>
                </div>
              )}

              {/* AI Analysis Result */}
              {analysisResult && (
                <div className="mt-4 p-5 rounded-2xl bg-purple-950/40 border border-pink-500/30 text-xs text-slate-200 space-y-2">
                  <span className="font-bold text-pink-400 flex items-center gap-2 text-sm">
                    <Sparkles className="w-4 h-4" />
                    {assistantName} Analysis Result:
                  </span>
                  <div className="whitespace-pre-wrap leading-relaxed">{analysisResult}</div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500">No file selected.</div>
          )}
        </div>
      </div>
    </div>
  );
};
