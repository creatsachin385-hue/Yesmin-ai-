import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { Project } from '../types';
import { getEffectiveAssistantName } from '../utils/personality';
import {
  FolderGit2,
  Plus,
  Trash2,
  FileCode,
  CheckSquare,
  MessageSquare,
  Sparkles,
  BookOpen,
  ArrowRight,
  Save,
} from 'lucide-react';

export const ProjectsView: React.FC = () => {
  const { settings, setActiveTab, showToast } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectType, setNewProjectType] = useState<Project['type']>('android_app');
  const [notesContent, setNotesContent] = useState('');

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const list = await api.getProjects();
      setProjects(list);
      if (list.length > 0 && !activeProjectId) {
        setActiveProjectId(list[0].id);
        setNotesContent(list[0].notes || '');
      }
    } catch (err: any) {
      showToast(err.message || 'Error loading projects', 'error');
    }
  };

  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0];

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim()) return;

    try {
      const created = await api.createProject(newProjectName.trim(), newProjectDesc.trim(), newProjectType);
      setProjects((prev) => [created, ...prev]);
      setActiveProjectId(created.id);
      setNotesContent('');
      setNewProjectName('');
      setNewProjectDesc('');
      setIsCreating(false);
      showToast(`Created project: ${created.name}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to create project', 'error');
    }
  };

  const handleSaveNotes = async () => {
    if (!activeProject) return;
    try {
      await api.updateProject(activeProject.id, { notes: notesContent });
      setProjects((prev) =>
        prev.map((p) => (p.id === activeProject.id ? { ...p, notes: notesContent } : p))
      );
      showToast('Project notes saved', 'success');
    } catch (err: any) {
      showToast('Failed to save notes', 'error');
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await api.deleteProject(id);
      const remaining = projects.filter((p) => p.id !== id);
      setProjects(remaining);
      if (activeProjectId === id && remaining.length > 0) {
        setActiveProjectId(remaining[0].id);
        setNotesContent(remaining[0].notes || '');
      }
      showToast('Project removed', 'info');
    } catch (err: any) {
      showToast('Failed to delete project', 'error');
    }
  };

  const handleOpenProjectChat = () => {
    if (!activeProject) return;
    const prompt = `Let's work on our project "${activeProject.name}" (${activeProject.description}). Project notes: ${activeProject.notes || 'None'}. What are the next architectural steps?`;
    sessionStorage.setItem('pending_quick_prompt', prompt);
    setActiveTab('chat');
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 max-w-6xl mx-auto space-y-6 pb-24 md:pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FolderGit2 className="w-5 h-5 text-violet-400" />
            Project Hub & Workspaces
          </h2>
          <p className="text-xs text-slate-400">
            Dedicated multi-modal hubs for Android Apps, Websites, AI Assistants, and Study projects.
          </p>
        </div>

        <button
          onClick={() => setIsCreating(!isCreating)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 text-white text-xs font-semibold shadow-lg shadow-violet-500/20 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      {/* Create Modal / Card */}
      {isCreating && (
        <form
          onSubmit={handleCreate}
          className="p-5 rounded-3xl bg-slate-900/80 border border-violet-500/40 backdrop-blur-xl space-y-4 shadow-xl"
        >
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-violet-400" />
            Create Workspace Project
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="Project Name (e.g. Android Companion App)"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-violet-500"
            />

            <input
              type="text"
              placeholder="Description or Target Goal"
              value={newProjectDesc}
              onChange={(e) => setNewProjectDesc(e.target.value)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-violet-500"
            />

            <select
              value={newProjectType}
              onChange={(e) => setNewProjectType(e.target.value as any)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-violet-500"
            >
              <option value="android_app">Android App</option>
              <option value="website">Website</option>
              <option value="ai_assistant">AI Assistant</option>
              <option value="coding">Coding Project</option>
              <option value="youtube">YouTube Project</option>
              <option value="study">Study Project</option>
              <option value="custom">Custom Project</option>
            </select>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs rounded-xl bg-violet-600 text-white font-semibold shadow"
            >
              Create Project
            </button>
          </div>
        </form>
      )}

      {/* Main Grid: Projects List + Active Project Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Project Selector */}
        <div className="lg:col-span-1 rounded-3xl bg-slate-900/50 border border-purple-900/30 p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            All Projects ({projects.length})
          </h3>

          <div className="space-y-2">
            {projects.map((p) => {
              const isActive = p.id === activeProjectId;
              return (
                <div
                  key={p.id}
                  onClick={() => {
                    setActiveProjectId(p.id);
                    setNotesContent(p.notes || '');
                  }}
                  className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-start justify-between group ${
                    isActive
                      ? 'bg-violet-500/20 border-violet-500/50 text-white'
                      : 'bg-slate-950/40 border-purple-900/20 text-slate-300 hover:bg-slate-900/80'
                  }`}
                >
                  <div className="space-y-1 overflow-hidden">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-violet-950 text-violet-300 border border-violet-800/40 uppercase">
                      {p.type.replace('_', ' ')}
                    </span>
                    <h4 className="text-xs font-bold truncate mt-1">{p.name}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{p.description}</p>
                  </div>

                  <button
                    onClick={(e) => handleDelete(p.id, e)}
                    className="opacity-0 group-hover:opacity-100 hover:text-red-400 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Project Hub Detail View */}
        <div className="lg:col-span-2 space-y-4">
          {activeProject ? (
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-purple-900/30">
                <div>
                  <h3 className="text-lg font-bold text-white">{activeProject.name}</h3>
                  <p className="text-xs text-slate-400">{activeProject.description || 'Workspace Hub'}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleOpenProjectChat}
                    className="px-3.5 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Project AI Chat</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('code')}
                    className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                  >
                    <FileCode className="w-3.5 h-3.5" />
                    <span>Open in Code Agent</span>
                  </button>
                </div>
              </div>

              {/* Notes & Instructions Area */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-violet-400" />
                    Workspace Notes & Instructions
                  </span>
                  <button
                    onClick={handleSaveNotes}
                    className="text-xs text-violet-400 hover:text-violet-300 font-semibold flex items-center gap-1"
                  >
                    <Save className="w-3 h-3" />
                    <span>Save Notes</span>
                  </button>
                </div>

                <textarea
                  value={notesContent}
                  onChange={(e) => setNotesContent(e.target.value)}
                  placeholder="Record ideas, design guidelines, dependencies, or prompts for this project..."
                  rows={5}
                  className="w-full p-3.5 rounded-2xl bg-slate-950 border border-purple-900/30 text-xs text-slate-200 focus:outline-none focus:border-violet-500 resize-none font-sans leading-relaxed"
                />
              </div>

              {/* Files in Project */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                  Files Attached ({activeProject.files?.length || 0})
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeProject.files?.map((f) => (
                    <div
                      key={f.id}
                      onClick={() => setActiveTab('code')}
                      className="p-3 rounded-xl bg-slate-950/60 border border-purple-900/20 hover:border-emerald-500/30 cursor-pointer flex items-center justify-between text-xs transition-all"
                    >
                      <span className="font-mono text-slate-300">{f.name}</span>
                      <span className="text-[10px] text-slate-500 uppercase">{f.language}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500">No project selected.</div>
          )}
        </div>
      </div>
    </div>
  );
};
