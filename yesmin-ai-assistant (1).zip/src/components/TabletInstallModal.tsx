import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useApp } from '../context/AppContext';
import {
  Tablet,
  Download,
  X,
  CheckCircle2,
  Sparkles,
  Smartphone,
  ExternalLink,
  HelpCircle,
  Copy,
} from 'lucide-react';

interface TabletInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TabletInstallModal: React.FC<TabletInstallModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const { settings, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk'>('pwa');

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        showToast('Yesmin AI Galaxy Tab A7 Lite par install ho gaya!', 'success');
        onClose();
      }
    } else {
      showToast('Browser menu (3 dots) se "Install App" choose karein', 'info');
    }
  };

  const copyUrl = () => {
    navigator.clipboard.writeText(window.location.origin);
    showToast('App URL copy ho gaya! Apne Galaxy Tab ke browser me open karein.', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-xl rounded-3xl bg-slate-900 border border-purple-800/60 p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-lg shadow-pink-500/30">
              <Tablet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Samsung Galaxy Tab A7 Lite Installation
              </h3>
              <p className="text-xs text-pink-400 font-medium">
                {settings.assistantName} Tablet Edition (Android One UI)
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: PWA (Instant) vs APK Wrapper */}
        <div className="flex rounded-2xl bg-slate-950 p-1 border border-purple-900/30 text-xs">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 py-2 rounded-xl font-bold transition-all ${
              activeTab === 'pwa'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Direct PWA Install (1-Click • सबसे आसान)
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-2 rounded-xl font-bold transition-all ${
              activeTab === 'apk'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Android APK Setup (Android Studio / WebView)
          </button>
        </div>

        {activeTab === 'pwa' ? (
          <div className="space-y-4 text-xs text-slate-300">
            {/* Status card */}
            <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono text-pink-400 font-bold">
                  Device Compatibility
                </span>
                <p className="text-white font-semibold mt-0.5">
                  Galaxy Tab A7 Lite (Android 11 / 12 / 13 / 14) Ready
                </p>
                <p className="text-[11px] text-slate-400">
                  Full offline caching, standalone window, mic & camera permissions included.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2">
                <a
                  href="/api/download-zip"
                  download="yesmin-ai-assistant.zip"
                  className="px-3.5 py-2 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 font-bold text-xs shadow flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download .ZIP</span>
                </a>

                {isInstalled ? (
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-[11px]">
                    Already Installed
                  </span>
                ) : (
                  <button
                    onClick={handleInstallClick}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 text-white font-bold shadow-lg shadow-pink-500/30 active:scale-95 transition-all flex items-center gap-1.5 shrink-0"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install on Galaxy Tab</span>
                  </button>
                )}
              </div>
            </div>

            {/* Step-by-Step Hindi Guide */}
            <div className="space-y-3 pt-1">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-pink-400" />
                Galaxy Tab A7 Lite me install karne ke 3 aasan steps:
              </h4>

              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-white">Galaxy Tab me Chrome ya Samsung Internet kholein</p>
                    <p className="text-[11px] text-slate-400">
                      Apne Galaxy Tab A7 Lite par is link ko open karein:
                    </p>
                    <div className="mt-1 flex items-center gap-2 bg-slate-900 px-2.5 py-1.5 rounded-xl border border-slate-800">
                      <span className="font-mono text-[11px] text-pink-300 truncate flex-1">
                        {window.location.origin}
                      </span>
                      <button
                        onClick={copyUrl}
                        className="text-pink-400 hover:text-pink-300 font-medium text-[10px] flex items-center gap-1 shrink-0"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copy Link</span>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-white">Browser ke 3 dots (⋮) Menu par tap karein</p>
                    <p className="text-[11px] text-slate-400">
                      Top-right corner me <strong className="text-white">3 dots (⋮)</strong> par click karein aur <strong className="text-pink-400">"Install app"</strong> ya <strong className="text-pink-400">"Add to Home screen"</strong> option par tap karein.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-white">"Install" button dabayein</p>
                    <p className="text-[11px] text-slate-400">
                      Galaxy Tab A7 Lite ki home screen aur App Drawer par <strong className="text-white">Yesmin AI</strong> ka app icon ban jayega. Ise open karte hi ye bilkul bina URL bar ke pure fullscreen native Android app ki tarah chalega!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4 text-xs text-slate-300">
            <p>
              Agar aap is web app ko <strong>.apk</strong> file me convert karke Galaxy Tab A7 Lite me direct install karna chahte hain, to niche diye gaye do tarike use kar sakte hain:
            </p>

            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                <h5 className="font-bold text-white text-xs">Option A: PWA Builder (Zero-Code APK)</h5>
                <p className="text-[11px] text-slate-400">
                  1. <a href="https://www.pwabuilder.com" target="_blank" rel="noopener noreferrer" className="text-pink-400 underline">PWABuilder.com</a> par jayein.<br />
                  2. Apne app ka live URL daalein.<br />
                  3. <strong>"Generate Android Package (.apk)"</strong> par click karke direct APK download karein aur Galaxy Tab me install karein!
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                <h5 className="font-bold text-white text-xs">Option B: Android Studio WebView Wrapper</h5>
                <p className="text-[11px] text-slate-400">
                  Android Studio me naya project banakar <code>MainActivity.kt</code> me webview load karein:
                </p>
                <pre className="p-2.5 rounded-xl bg-black font-mono text-[10px] text-emerald-400 overflow-x-auto">
{`webView.settings.javaScriptEnabled = true
webView.settings.domStorageEnabled = true
webView.settings.mediaPlaybackRequiresUserGesture = false
webView.loadUrl("${window.location.origin}")`}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-purple-900/40">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-semibold hover:bg-slate-700 transition-colors"
          >
            Samajh Gaya (Done)
          </button>
        </div>
      </div>
    </div>
  );
};
