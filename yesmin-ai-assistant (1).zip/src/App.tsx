import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { HomeDashboard } from './components/HomeDashboard';
import { ChatView } from './components/ChatView';
import { LiveVoiceView } from './components/LiveVoiceView';
import { CodingAgentView } from './components/CodingAgentView';
import { AppsActionsView } from './components/AppsActionsView';
import { WebSearchView } from './components/WebSearchView';
import { FilesView } from './components/FilesView';
import { MemoryView } from './components/MemoryView';
import { ProjectsView } from './components/ProjectsView';
import { TasksView } from './components/TasksView';
import { SettingsView } from './components/SettingsView';
import { X, CheckCircle2, AlertCircle, Info } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeTab, toasts, removeToast } = useApp();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'home':
        return <HomeDashboard />;
      case 'chat':
        return <ChatView />;
      case 'live':
        return <LiveVoiceView />;
      case 'code':
        return <CodingAgentView />;
      case 'actions':
        return <AppsActionsView />;
      case 'search':
        return <WebSearchView />;
      case 'files':
        return <FilesView />;
      case 'memory':
        return <MemoryView />;
      case 'projects':
        return <ProjectsView />;
      case 'tasks':
        return <TasksView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <HomeDashboard />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#070814] text-slate-100 font-sans selection:bg-pink-500/30 selection:text-white">
      {/* Sidebar Navigation */}
      <Navigation />

      {/* Main View Container */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        <Header />

        <main className="flex-1 overflow-hidden flex flex-col relative bg-radial-gradient">
          {renderActiveView()}
        </main>
      </div>

      {/* Floating Global Toasts */}
      <div className="fixed top-20 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center justify-between gap-3 p-3.5 rounded-2xl shadow-2xl border text-xs backdrop-blur-2xl transition-all animate-in slide-in-from-top-2 ${
              toast.type === 'success'
                ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                : toast.type === 'error'
                ? 'bg-red-950/80 border-red-500/50 text-red-200'
                : toast.type === 'warning'
                ? 'bg-amber-950/80 border-amber-500/50 text-amber-200'
                : 'bg-slate-900/90 border-purple-800/60 text-purple-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : toast.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              ) : (
                <Info className="w-4 h-4 text-pink-400 shrink-0" />
              )}
              <span>{toast.text}</span>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-white p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
