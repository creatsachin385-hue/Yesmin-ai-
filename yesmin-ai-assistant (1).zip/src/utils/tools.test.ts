import test from 'node:test';
import assert from 'node:assert/strict';
import { safeCalculate, isActionSensitive, parseAssistantActions } from './tools';

test('safeCalculate performs arithmetic correctly and rejects malicious input', () => {
  const r1 = safeCalculate('15 * 4 + 20');
  assert.equal(r1.success, true);
  assert.equal(r1.result, 80);

  const r2 = safeCalculate('(100 - 25) / 5');
  assert.equal(r2.success, true);
  assert.equal(r2.result, 15);

  const r3 = safeCalculate('');
  assert.equal(r3.success, false);

  // Dangerous script characters are filtered
  const r4 = safeCalculate('process.exit()');
  assert.equal(r4.success, false);
});

test('isActionSensitive flags dangerous operations', () => {
  assert.equal(isActionSensitive('RUN_CODE'), true);
  assert.equal(isActionSensitive('CREATE_FILE', { overwrite: true }), true);
  assert.equal(isActionSensitive('CREATE_FILE', { overwrite: false }), false);
  assert.equal(isActionSensitive('OPEN_URL'), false);
  assert.equal(isActionSensitive('CALCULATE'), false);
});

test('parseAssistantActions extracts action tags and cleans text', () => {
  const text = 'Here is the video you wanted: [ACTION:OPEN_URL:{"url":"https://youtube.com","title":"YouTube"}] Enjoy!';
  const parsed = parseAssistantActions(text);
  assert.equal(parsed.actions.length, 1);
  assert.equal(parsed.actions[0].type, 'OPEN_URL');
  assert.equal(parsed.actions[0].parameters.url, 'https://youtube.com');
  assert.ok(!parsed.cleanText.includes('[ACTION:'));
});
