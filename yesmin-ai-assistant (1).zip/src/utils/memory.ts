/**
 * Memory Management & Relevance Matching
 */
import { MemoryItem } from '../types';

export function searchMemories(memories: MemoryItem[], query: string): MemoryItem[] {
  if (!query || !query.trim()) return memories;
  const q = query.toLowerCase().trim();
  return memories.filter(
    (m) =>
      m.key.toLowerCase().includes(q) ||
      m.value.toLowerCase().includes(q) ||
      m.category.toLowerCase().includes(q)
  );
}

export function findRelevantMemories(memories: MemoryItem[], contextText: string, limit = 8): MemoryItem[] {
  if (!memories.length) return [];
  const words = contextText
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 2);

  const scored = memories.map((item) => {
    let score = 0;
    const combined = `${item.key} ${item.value} ${item.category}`.toLowerCase();
    for (const w of words) {
      if (combined.includes(w)) {
        score += 1;
      }
    }
    return { item, score };
  });

  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.item);
}

export function extractAutoMemoryCandidates(userText: string): { key: string; value: string; category: MemoryItem['category'] } | null {
  const text = userText.trim();

  // Pattern: "my favorite X is Y" or "mera favorite X Y hai"
  const favMatch = text.match(/my fav(?:orite)? ([a-z ]+) is (.+)/i);
  if (favMatch) {
    return {
      key: `Favorite ${favMatch[1].trim()}`,
      value: favMatch[2].trim(),
      category: 'preference'
    };
  }

  // Pattern: "remember that I ..." or "yaad rakhna ki ..."
  const rememberMatch = text.match(/(?:please )?(?:remember that|yaad rakhna ki) (.+)/i);
  if (rememberMatch) {
    return {
      key: 'User Instruction',
      value: rememberMatch[1].trim(),
      category: 'instruction'
    };
  }

  // Pattern: "call me X" / "mujhe X bulao"
  const callMeMatch = text.match(/(?:call me|mujhe) ([a-zA-Z0-9_-]+)(?: bulao)?/i);
  if (callMeMatch) {
    return {
      key: 'Preferred Nickname',
      value: callMeMatch[1].trim(),
      category: 'preference'
    };
  }

  return null;
}
